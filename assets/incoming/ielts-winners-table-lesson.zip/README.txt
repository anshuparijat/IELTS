IELTS Winners — lesson package
Slides are numbered in presentation order.
Narration is in narration.txt.
Voice requirement: Microsoft Edge TTS en-US-AndrewNeural only.
Video target: vertical 9:16.
Important source check: Canada / Others is inconsistent across the supplied graphics (14% in the table image, 44% in the ranking and sample-answer images). Narration flags this discrepancy rather than hiding it.
